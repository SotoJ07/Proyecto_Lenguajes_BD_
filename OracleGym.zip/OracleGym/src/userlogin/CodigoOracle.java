/** 
 -- Crear Tabla 
CREATE TABLE Clientes (
    idCliente NUMBER,
    nombre VARCHAR2(30),
    direccion VARCHAR2(30),
    telefono NUMBER,
    email VARCHAR2(30),
    fechaRegistro DATE
);

-- Procedimiento Agregar Cliente 
CREATE OR REPLACE PROCEDURE AGREGAR_CLIENTE (
    idCliente IN NUMBER,
    nombre IN VARCHAR2,
    direccion IN VARCHAR2,
    telefono IN NUMBER,
    email IN VARCHAR2,
    fechaRegistro IN DATE
)
AS
BEGIN
    INSERT INTO Clientes (idCliente, nombre, direccion, telefono, email, fechaRegistro)
    VALUES (idCliente, nombre, direccion, telefono, email, fechaRegistro);
END;

SELECT * FROM Entrenadores;

CREATE TABLE Entrenadores (
    idEntrenador NUMBER,
    nombre VARCHAR2(30),
    especialidad VARCHAR2(30),
    disponibilidad VARCHAR2(30),
    perfil VARCHAR(30)
);

CREATE OR REPLACE PROCEDURE AGREGAR_ENTRENADOR (
    idEntrenador IN NUMBER,
    nombre IN VARCHAR2,
    especialidad IN VARCHAR2,
    disponibilidad IN VARCHAR2,
    perfil IN VARCHAR2
)
AS
BEGIN
    INSERT INTO Entrenadores (idEntrenador, nombre, especialidad, disponibilidad, perfil)
    VALUES (idEntrenador, nombre, especialidad, disponibilidad, perfil);
END;



CREATE OR REPLACE PROCEDURE actualizar_cliente (
    p_cliente_id IN NUMBER,  
    p_nombre IN VARCHAR2,   
    p_direccion IN VARCHAR2,
    p_telefono IN VARCHAR2,  
    p_email IN VARCHAR2,    
    p_fecha_registro IN DATE 
) AS
BEGIN
    UPDATE clientes
    SET nombre = p_nombre, 
        direccion = p_direccion, 
        telefono = p_telefono, 
        email = p_email, 
        fecha_registro = p_fecha_registro
    WHERE cliente_id = p_cliente_id; 
END actualizar_cliente;
/

EXEC actualizar_cliente(1, 'Jennifer', 'Heredia', '8888-9999', 'jenn123@gmail.com', '12-Mar-2001');

SELECT * FROM CLIENTES;

-- Ejecución del procedimiento
BEGIN
    actualizar_cliente(1, 'Juan', 'Cartago', '8888-9999', 'juan123@gmail.com', TO_DATE('12-ENE-2001', 'DD-MON-YYYY'));
END;
/

INSERT INTO CLIENTES (cliente_id, nombre, direccion, telefono, email, fecha_registro)
VALUES (1, 'Juan', 'Cartago', '8888-9999', 'juan123@gmail.com', TO_DATE('12-JAN-2001', 'DD-MON-YYYY'));


-----------------------------------

CREATE OR REPLACE PROCEDURE eliminar_cliente (
    n_cliente_id IN NUMBER
) AS
BEGIN
    DELETE FROM clientes
    WHERE cliente_id = n_cliente_id;
    COMMIT;
END eliminar_cliente;

---------------------------------------

CREATE OR REPLACE PROCEDURE registrar_acceso_cliente (
    n_cliente_id IN NUMBER,
    n_fecha_entrada IN DATE,
    n_fecha_salida IN DATE
) AS
BEGIN
    INSERT INTO accesos (cliente_id, fecha_entrada, fecha_salida)
    VALUES (n_cliente_id, n_fecha_entrada, n_fecha_salida);
END registrar_acceso_cliente;
--------

CREATE OR REPLACE PROCEDURE registrar_pago (
    n_pago_id IN NUMBER,
    n_factura_id IN NUMBER,
    n_monto_pago IN NUMBER, 
    n_fecha_pago IN DATE,
    n_metodo_pago IN VARCHAR2
) AS
BEGIN
    INSERT INTO Pagos (pago_id, factura_id, monto_pago, fecha_pago, metodo_pago)
    VALUES (n_pago_id, n_factura_id, n_monto_pago, n_fecha_pago, n_metodo_pago);
END registrar_pago;


--------------------------------

CREATE OR REPLACE PROCEDURE actualizar_membresia_cliente (
    n_cliente_id IN NUMBER,
    n_tipo_membresia IN VARCHAR,
    n_estado IN VARCHAR
    
) AS
BEGIN
    UPDATE membresias
    SET tipo_membresia = n_tipo_membresia, estado = n_estado 
    WHERE cliente_id = n_cliente_id;
END actualizar_membresia_cliente;

------------------------------------------------

CREATE OR REPLACE PROCEDURE registrar_reserva (
    n_reserva_id IN NUMBER,
    n_cliente_id IN NUMBER,
    n_clase_id IN NUMBER,
    n_entrenador_id IN NUMBER,
    n_fecha_reserva IN DATE,
    n_estado IN VARCHAR
    
) AS
BEGIN
    INSERT INTO reservas (reserva_id, cliente_id, clase_id, entrenador_id, fecha_reserva, estado)
    VALUES (n_reserva_id, n_cliente_id, n_clase_id, n_entrenador_id, n_fecha_reserva, n_estado);
END registrar_reserva;

----------------------------------------------------

CREATE OR REPLACE PROCEDURE registrar_clase (
    n_clase_id IN NUMBER,
    n_nombre_clase IN VARCHAR,
    n_capacidad IN NUMBER,
    n_fecha_clase IN DATE,
    n_duracion_minutos IN NUMBER
) AS
BEGIN
    INSERT INTO clases (clase_id, nombre_clase, capacidad, fecha_clase, duracion_minutos)
    VALUES (n_clase_id, n_nombre_clase, n_capacidad, n_fecha_clase, n_duracion_minutos);
END registrar_clase;


-----------------------------------------------------

CREATE OR REPLACE PROCEDURE obtener_estado_fisico_cliente (
    n_cliente_id IN NUMBER
) AS
BEGIN
    FOR estado_fisico IN (SELECT peso, grasa_corporal FROM ESTADOFISICO WHERE cliente_id = n_cliente_id) LOOP
        DBMS_OUTPUT.PUT_LINE('El cliente con ID: ' || n_cliente_id || ', Pesa: ' || estado_fisico.peso || ', tiene una grasa corporal de: ' || estado_fisico.grasa_corporal);
    END LOOP;
END obtener_estado_fisico_cliente;



-------------------------------------------

CREATE OR REPLACE PROCEDURE asignar_rutina (
    n_cliente_id IN NUMBER,
    n_rutina_id IN NUMBER
) AS
BEGIN
    INSERT INTO rutinas (cliente_id, rutina_id)
    VALUES (n_cliente_id, n_rutina_id);
END asignar_rutina;

--------------------------------------------------------------

CREATE OR REPLACE PROCEDURE actualizar_entrenador (
    n_entrenador_id IN NUMBER,
    n_nombre_entrenador IN VARCHAR2,
    n_especialidad IN VARCHAR2,
    n_disponibilidad IN VARCHAR2,
    n_perfil IN VARCHAR2
) AS
BEGIN
    UPDATE entrenadores
    SET nombre_entrenador = n_nombre_entrenador, especialidad = n_especialidad, disponibilidad = n_disponibilidad, perfil = n_perfil
    WHERE entrenador_id = n_entrenador_id;
END actualizar_entrenador;

----------------------------------------------

CREATE OR REPLACE PROCEDURE eliminar_entrenador (
    n_entrenador_id IN NUMBER
) AS
BEGIN
    DELETE FROM entrenadores
    WHERE entrenador_id = n_entrenador_id;
END eliminar_entrenador;

-----------------------------------------------------

 
CREATE OR REPLACE PROCEDURE asignar_entrenador_clase (
    n_entrenador_id IN NUMBER,  
    n_id_clase IN NUMBER        
) AS
BEGIN
    INSERT INTO asignacion_clases (entrenador_id, id_clase)
    VALUES (n_entrenador_id, n_id_clase);
END asignar_entrenador_clase;
/

CREATE TABLE asignacion_clases(entrenador_id NUMBER, id_clase NUMBER);
-------------------------------------------------

CREATE OR REPLACE PROCEDURE obtener_entrenadores_disponibles AS
BEGIN
    FOR entrenador IN (SELECT nombre_entrenador, especialidad, disponibilidad FROM entrenadores WHERE perfil = 'Entrenador') LOOP
        DBMS_OUTPUT.PUT_LINE('Entrenador: ' || entrenador.nombre_entrenador || ', especializado en: ' || entrenador.especialidad || ', esta disponible: ' || entrenador.disponibilidad);
    END LOOP;
END obtener_entrenadores_disponibles;

----------------------------------------------------------

CREATE OR REPLACE PROCEDURE cambiar_especialidad_entrenador (
    n_entrenador_id IN NUMBER,
    n_nueva_especialidad IN VARCHAR2
) AS
BEGIN
    UPDATE entrenadores
    SET especialidad = n_nueva_especialidad
    WHERE entrenador_id = n_entrenador_id;
END cambiar_especialidad_entrenador;

* 
* 
* CREATE VIEW v_clientes_membresias AS
SELECT 
    c.cliente_id, 
    c.nombre AS nombre_cliente, 
    m.tipo_membresia, 
    m.fecha_inicio, 
    m.fecha_fin, 
    m.estado
FROM 
    Clientes c
JOIN 
    Membresias m ON c.cliente_id = m.cliente_id
WHERE 
    m.estado = 'Activa';
 
 
2. Vista para clases programadas y su capacidad
CREATE VIEW v_clases_programadas AS
SELECT 
    clase_id, 
    nombre_clase, 
    capacidad, 
    fecha_clase, 
    duracion_minutos
FROM 
    Clases
WHERE 
    fecha_clase > CURRENT_TIMESTAMP;
 
 
3. Vista de reservas activas con detalles del cliente y la clase
CREATE VIEW v_reservas_activas AS
SELECT 
    r.reserva_id, 
    c.nombre AS nombre_cliente, 
    cl.nombre_clase, 
    r.fecha_reserva, 
    r.estado
FROM 
    Reservas r
JOIN 
    Clientes c ON r.cliente_id = c.cliente_id
JOIN 
    Clases cl ON r.clase_id = cl.clase_id
WHERE 
    r.estado = 'Activa';
 
 
4. Vista de rutinas asignadas a clientes
CREATE VIEW v_rutinas_cliente AS
SELECT 
    r.rutina_id, 
    c.nombre AS nombre_cliente, 
    e.nombre_entrenador, 
    r.descripcion, 
    r.fecha_asignacion
FROM 
    Rutinas r
JOIN 
    Clientes c ON r.cliente_id = c.cliente_id
JOIN 
    Entrenadores e ON r.entrenador_id = e.entrenador_id;
 
 
5. Vista de pagos realizados por factura
CREATE VIEW v_pagos_facturas AS
SELECT 
    p.pago_id, 
    f.factura_id, 
    c.nombre AS nombre_cliente, 
    f.monto AS monto_factura, 
    p.monto_pago, 
    p.fecha_pago, 
    p.metodo_pago
FROM 
    Pagos p
JOIN 
    Facturacion f ON p.factura_id = f.factura_id
JOIN 
    Clientes c ON f.cliente_id = c.cliente_id;
 
 
6. Vista de estado físico de los clientes
CREATE VIEW v_estado_fisico AS
SELECT 
    e.estado_id, 
    c.nombre AS nombre_cliente, 
    e.peso, 
    e.grasa_corporal, 
    e.fecha_registro
FROM 
    EstadoFisico e
JOIN 
    Clientes c ON e.cliente_id = c.cliente_id;
 
 
7. Vista del inventario disponible
 
CREATE VIEW v_inventario_disponible AS
SELECT 
    item_id, 
    nombre_item, 
    cantidad, 
    estado
FROM 
    Inventario
WHERE 
    estado = 'Disponible';
 
 
8. Vista de accesos de clientes recientes
 
CREATE VIEW v_accesos_clientes AS
SELECT 
    a.acceso_id, 
    c.nombre AS nombre_cliente, 
    a.fecha_entrada, 
    a.fecha_salida
FROM 
    Accesos a
JOIN 
    Clientes c ON a.cliente_id = c.cliente_id
WHERE 
    a.fecha_entrada > CURRENT_TIMESTAMP - INTERVAL '7' DAY;
 
 
9. Vista de notificaciones enviadas a clientes
 
CREATE VIEW v_notificaciones_enviadas AS
SELECT 
    n.notificacion_id, 
    c.nombre AS nombre_cliente, 
    n.mensaje, 
    n.fecha_envio
FROM 
    Notificaciones n
JOIN 
    Clientes c ON n.cliente_id = c.cliente_id;
 
 
10. Vista de entrenadores y las clases asignadas
CREATE VIEW v_entrenadores_clases AS
SELECT 
    e.entrenador_id, 
    e.nombre_entrenador, 
    cl.nombre_clase, 
    cl.fecha_clase
FROM 
    asignacion_clases ac
JOIN 
    Entrenadores e ON ac.entrenador_id = e.entrenador_id
JOIN 
    Clases cl ON ac.id_clase = cl.clase_id;
 
 
11. Vista de facturación mensual por cliente
CREATE VIEW v_facturacion_mensual AS
SELECT 
    c.cliente_id, 
    c.nombre AS nombre_cliente, 
    SUM(f.monto) AS total_facturado, 
    TO_CHAR(f.fecha_factura, 'YYYY-MM') AS mes
FROM 
    Facturacion f
JOIN 
    Clientes c ON f.cliente_id = c.cliente_id
GROUP BY 
    c.cliente_id, c.nombre, TO_CHAR(f.fecha_factura, 'YYYY-MM');
 
 
12. Vista de clientes sin actividad reciente (accesos o reservas)
CREATE VIEW v_clientes_inactivos AS
SELECT 
    c.cliente_id, 
    c.nombre, 
    c.email, 
    MAX(a.fecha_entrada) AS ultimo_acceso, 
    MAX(r.fecha_reserva) AS ultima_reserva
FROM 
    Clientes c
LEFT JOIN 
    Accesos a ON c.cliente_id = a.cliente_id
LEFT JOIN 
    Reservas r ON c.cliente_id = r.cliente_id
GROUP BY 
    c.cliente_id, c.nombre, c.email
HAVING 
    MAX(a.fecha_entrada) < CURRENT_DATE - 30 
    AND MAX(r.fecha_reserva) < CURRENT_DATE - 30;
    
*/
