/** 
 * CREATE TABLE Clientes (
  *  idCliente NUMBER,
   *nombre VARCHAR2(30),
   * direccion VARCHAR2(30),
   *Telefono NUMBER,
   * Email VARCHAR(30),
    *fechaRegistro DATE
   * );

*CREATE OR REPLACE PROCEDURE agregar_cliente (
 *   id_Cliente IN NUMBER,
    nombreCliente IN VARCHAR2,
    direccionCliente IN VARCHAR2,
    telefonoCliente IN NUMBER,
    fecha_Registro IN DATE
) AS
BEGIN
    INSERT INTO Clientes (idCliente, nombre, direccion, Telefono, fecharegistro)
    VALUES (id_Cliente, nombreCliente, direccionCliente, telefonoCliente, fecha_Registro);
END;
*/