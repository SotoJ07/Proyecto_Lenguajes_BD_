/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package userlogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.SQLException;

/**
 *
 * @author jenns
 */
public class Conexion {
    
    public Connection establecerConnection() {
    Connection conn = null;
       
    Connection conectar = null;
    String usuario = "HR"; // TENEMOS QUE CAMBIAR AL USUARIO REAL
    String contrasena = "12345"; // CONTRASENA DE ORACLE
    String bd = "ORCL";
    String ip= "localhost";
    String puerto = "1521";
    
    String jdbcUrl = "jdbc:oracle:thin:@" + ip + ":" + puerto + ":" + bd;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection(jdbcUrl, usuario, contrasena);
            System.out.println("Se conecto a la base de datos Oracle");
        } catch (ClassNotFoundException e) {
            System.out.println("Error de connecion: ");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("No se pudo conectar");
            e.printStackTrace();
        }

        return conn;
    }
}

/**
    public  Connection establecerConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conectar = DriverManager.getConnection(cadena, usuario, contrasena);
            JOptionPane.showMessageDialog(null, "se estableció conexión con la base de datos sql server");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos: " + e.toString());
        }
        return conectar;
    }
}
        
        
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:orcl";
            String uname = "HR"; // nombre del usuario de la base de datos
            String upass = "12345";//contrasena de base de datos
            conn = DriverManager.getConnection(url,uname,upass);
            String sql = "SELECT * FROM REGIONS";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
              System.out.print("REGION_ID"+"\t"+"REGION_NAME");
            System.out.println(rs.getString(1)+"\t\t"+rs.getString(2));
            }
        } catch (Exception e) {
          JOptionPane.showMessageDialog(null, e);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return conn;
    }
*/
    